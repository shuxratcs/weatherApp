const weatherIcon = $(".weather-icon");
const errorDisplay = $(".error");
const weatherDisplay = $(".weather");

async function checkWeather() {
    try {
        const response = await fetch(`http://localhost:8080/weather`);
        const data = await response.json();

        if (response.status === 404) {
            errorDisplay.addClass("display-block");
            weatherDisplay.addClass("display-none");
        } else {
            localStorage.setItem('weatherData', JSON.stringify(data[data.length - 1]));
            displayLastWeatherData(data[data.length - 1]);
            errorDisplay.removeClass("display-block");
            weatherDisplay.removeClass("display-none");
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

$(document).ready(function() {
    const cachedWeatherData = localStorage.getItem('weatherData');
    if (cachedWeatherData) {
        const data = JSON.parse(cachedWeatherData);
        displayLastWeatherData(data);
    } else {
        fetchWeatherData();
    }

    function fetchWeatherData() {
        $.getJSON(`http://localhost:8080/weather`)
            .done(function(data) {
                localStorage.setItem('weatherData', JSON.stringify(data[data.length - 1]));
                displayLastWeatherData(data[data.length - 1]);
            })
            .fail(function(error) {
                console.error('Error:', error);
            });
    }

    function displayLastWeatherData(data) {
        $("#city").html(data.city);
        $("#temperature").html(Math.round(data.temperature) + "°c");
        $("#pressure").html(data.pressure + " mbar");
        $("#feeling").html(Math.round(data.feeling) + "°c");
        $("#humidity").html(data.humidity + "%");
        $("#wind").html(data.wind + " km/h");

        const weatherImages = {
            "Clear": "clear.png",
            "Clouds": "clouds.png",
            "Drizzle": "drizzle.png",
            "Fog": "fog.png",
            "Mist": "mist.png",
            "Rain": "rain.png",
            "Snow": "snow.png"
        };

        weatherIcon.attr("src", "src/main/front/images/condition/" + weatherImages[data.weather]);
    }
});
